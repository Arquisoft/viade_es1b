import Mapa from './map.component';

export default Mapa;
